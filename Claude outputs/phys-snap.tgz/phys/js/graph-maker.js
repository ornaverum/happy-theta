/* Graph Maker page — qualitative motion graphs.
   Click twice to place the endpoints of a segment, move the mouse to bend it, click again to keep it. */
'use strict';

(function () {
	const { el, button, editLabel, Stage } = HT;

	const Y_LABELS = {
		Position: { name: 'Position', color: 'blue' },
		Velocity: { name: 'Velocity', color: 'green' },
		Acceleration: { name: 'Acceleration', color: 'red' }
	};
	const NEXT_Y = { Position: 'Velocity', Velocity: 'Acceleration', Acceleration: 'Position' };

	/* Default grid in graph units: time 0..6 to the right, value -3..3. Each graph can change its own. */
	const COLS = 6; // cells the card is sized for
	const DEFAULT_AXES = { x: { min: 0, max: 6 }, y: { min: -3, max: 3 } };
	const AXIS_LIMITS = { x: { minCells: 2, maxCells: 16 }, y: { minCells: 2, maxCells: 16 } };
	const newAxes = () => HT.clone(DEFAULT_AXES);
	/* Canvas padding around the grid (room for the axis arrowheads) */
	const PAD = { l: 4, r: 16, t: 16, b: 4 };

	let graphSize = 200; // grid width/height in px; set by fitGraphs()

	class QualGraph {
		constructor(graph, { onDelete = () => {} } = {}) {
			this.graph = graph; // { title, graphID, groupID, pathList, labels, axes }
			this.onDelete = onDelete;
			this.onStage = false;
			this.dotList = []; // endpoints being placed, in graph units
			this.addingDot = true;
			this.previewDot = null;
			this.previewPath = null;
			this.build();
			this.resize();
		}

		get color() {
			return Y_LABELS[this.graph.labels.y].color;
		}

		get axes() {
			return this.graph.axes;
		}
		get cols() {
			return this.axes.x.max - this.axes.x.min;
		}
		get rows() {
			return this.axes.y.max - this.axes.y.min;
		}
		/* square cells; the longer side keeps the card's size */
		get cell() {
			return graphSize / Math.max(this.cols, this.rows);
		}

		/* graph units <-> canvas pixels */
		toPx(p) {
			const cs = this.cell;
			return { x: PAD.l + (p.x - this.axes.x.min) * cs, y: PAD.t + (this.axes.y.max - p.y) * cs };
		}
		snap(px) {
			const cs = this.cell;
			const a = this.axes;
			const x = a.x.min + Math.round((px.x - PAD.l) / cs);
			const y = a.y.max - Math.round((px.y - PAD.t) / cs);
			return { x: Math.min(a.x.max, Math.max(a.x.min, x)) + 0, y: Math.min(a.y.max, Math.max(a.y.min, y)) + 0 };
		}

		build() {
			const ctrls = el(
				'div',
				{ class: 'qg-ctrls ctrl-only' },
				button({ cls: 'btn-red', icon: 'refresh', tip: 'Erase this graph', extra: 'btn-xs', onclick: () => this.erase() }),
				button({ cls: 'btn-red', icon: 'trash', tip: 'Delete this graph', extra: 'btn-xs', onclick: () => this.onDelete(this.graph.graphID) })
			);
			this.title = editLabel({ text: this.graph.title, size: 'md', onchange: (t) => (this.graph.title = t) });

			this.yLabel = el('button', {
				type: 'button',
				class: 'qg-ylabel',
				title: 'Click to switch between position, velocity and acceleration',
				onclick: () => {
					this.graph.labels.y = NEXT_Y[this.graph.labels.y];
					this.paintYLabel();
					this.draw();
				}
			});
			this.paintYLabel();

			const stageBox = el('div', { class: 'qg-stage' });
			this.stage = new Stage(stageBox);
			this.stage.on({
				enter: () => {
					this.onStage = true;
					this.draw();
				},
				leave: () => {
					this.onStage = false;
					this.draw();
				},
				move: (p) => this.handleMove(p),
				click: (p) => this.handleClick(p)
			});

			this.xLabel = el('div', { class: 'qg-xlabel', text: this.graph.labels.x });

			this.gridCtrls = HT.gridControls({
				axes: ['x', 'y'],
				names: { x: 'Time', y: 'Value' },
				limits: AXIS_LIMITS,
				get: () => this.axes,
				set: (ax, r) => {
					this.axes[ax] = r;
					this.dotList = []; // drop a half-placed segment
					this.addingDot = true;
					this.previewPath = null;
					this.resize();
				}
			});

			this.root = el(
				'div',
				{ class: 'qg-card' },
				el('div', { class: 'qg-head' }, this.title.el, ctrls),
				el('div', { class: 'qg-body' }, this.yLabel, stageBox, el('div'), this.xLabel),
				this.gridCtrls.el
			);
		}

		paintYLabel() {
			this.yLabel.textContent = this.graph.labels.y;
			this.yLabel.style.color = this.color;
		}

		resize() {
			const w = PAD.l + this.cols * this.cell + PAD.r;
			const h = PAD.t + this.rows * this.cell + PAD.b;
			this.stage.resize(w, h);
			// line the labels up with the grid itself, not the padded canvas
			this.yLabel.style.marginTop = PAD.t + 'px';
			this.yLabel.style.marginBottom = PAD.b + 'px';
			this.xLabel.style.paddingLeft = PAD.l + 'px';
			this.xLabel.style.paddingRight = PAD.r + 'px';
			this.draw();
		}

		setTitle(t) {
			this.graph.title = t;
			this.title.setText(t);
		}

		/* Quadratic curve between two endpoints; curvature -1, 0 or 1 */
		pathFor(a, b, curvature = 0) {
			const ctrl = a.y + (b.y - a.y) * 0.5 * (1 - curvature);
			return { a: { ...a }, b: { ...b }, c: { x: (a.x + b.x) / 2, y: ctrl }, bend: curvature };
		}

		curvature(pos) {
			if (this.dotList.length != 2) return 0;
			const a = this.toPx(this.dotList[0]).y;
			const b = this.toPx(this.dotList[1]).y;
			if (pos.y > Math.max(a, b) / 2 + (a + b) / 4) return -Math.sign(b - a);
			if (pos.y < Math.min(a, b) / 2 + (a + b) / 4) return Math.sign(b - a);
			return 0;
		}

		handleMove(pos) {
			if (this.addingDot) this.previewDot = this.snap(pos);
			else this.previewPath = this.pathFor(this.dotList[0], this.dotList[1], this.curvature(pos));
			this.draw();
		}

		handleClick(pos) {
			if (this.addingDot) {
				this.dotList.push(this.snap(pos));
				if (this.dotList.length > 1) {
					this.addingDot = false;
					this.previewPath = this.pathFor(this.dotList[0], this.dotList[1], 0);
				}
			} else {
				this.graph.pathList.push(this.previewPath);
				this.dotList = [];
				this.previewPath = null;
				this.addingDot = true;
				this.previewDot = this.snap(pos);
			}
			this.draw();
		}

		erase() {
			this.dotList = [];
			this.graph.pathList = [];
			this.previewPath = null;
			this.addingDot = true;
			this.draw();
		}

		drawGrid() {
			const s = this.stage;
			const cs = this.cell;
			const W = this.cols * cs;
			const H = this.rows * cs;
			for (let i = 0; i <= this.cols; i++) {
				const x = PAD.l + i * cs;
				s.line(x, PAD.t, x, PAD.t + H, { stroke: '#9ca3af', strokeWidth: 1 });
			}
			for (let j = 0; j <= this.rows; j++) {
				const y = PAD.t + j * cs;
				s.line(PAD.l, y, PAD.l + W, y, { stroke: '#9ca3af', strokeWidth: 1 });
			}
			// axes through the origin: time axis with an arrow on the right; value axis with an arrow on top
			const o = this.toPx({ x: 0, y: 0 });
			const axis = { stroke: 'black', fill: 'black', strokeWidth: 3, pointerLength: 9, pointerWidth: 9 };
			s.arrow(PAD.l, o.y, PAD.l + W + PAD.r - 2, o.y, axis);
			s.arrow(o.x, PAD.t + H, o.x, 2, axis);
		}

		drawPath(p, opacity = 1) {
			const a = this.toPx(p.a);
			const b = this.toPx(p.b);
			const c = this.toPx(p.c);
			this.stage.quad(a.x, a.y, c.x, c.y, b.x, b.y, { stroke: this.color, strokeWidth: 4, opacity });
		}

		draw() {
			const s = this.stage;
			const color = this.color;
			const r = Math.max(5, graphSize / 30);
			s.clear();
			this.drawGrid();
			for (const p of this.graph.pathList) this.drawPath(p);
			if (!this.addingDot && this.previewPath) this.drawPath(this.previewPath, 0.6);
			for (const d of this.dotList) {
				const q = this.toPx(d);
				s.circle(q.x, q.y, r, { fill: color });
			}
			if (this.onStage && this.addingDot && this.previewDot) {
				const q = this.toPx(this.previewDot);
				s.circle(q.x, q.y, r, { fill: color, opacity: 0.5 });
			}
		}
	}

	/* ---------------- page ---------------- */
	const container = el('div', { class: 'gm-groups' });
	const addGroupBtn = button({
		cls: 'btn-alt',
		icon: 'plusCircle',
		text: 'Add New Group',
		extra: 'w-full ctrl-only gm-add-group',
		onclick: () => {
			groupIDs.push(++groupIDIncrement);
			render();
		}
	});
	const hint = el('p', {
		class: 'gm-hint',
		text: 'Click two grid points to place a segment’s endpoints, move the mouse up or down to bend it, then click again to keep it. Click a graph’s side label to switch between position, velocity and acceleration.'
	});
	HT.capture.append(container, addGroupBtn);
	HT.capture.parentElement.insertBefore(hint, HT.capture);

	let graphs = [];
	let groupIDs = [0];
	let groupIDIncrement = 0;
	let graphIDIncrement = 0;
	const views = new Map(); // graphID -> QualGraph
	const groupLabels = new Map(); // groupID -> label text

	function viewFor(g) {
		if (!views.has(g.graphID)) views.set(g.graphID, new QualGraph(g, { onDelete: handleDelete }));
		return views.get(g.graphID);
	}

	function addNewGraph(groupID) {
		// a new graph copies the grid of the last graph in its group
		const prev = graphs.filter((g) => g.groupID === groupID).pop();
		graphs.push({
			title: 'Title',
			graphID: ++graphIDIncrement,
			groupID,
			pathList: [],
			labels: { x: 'Time', y: 'Position' },
			axes: prev ? HT.clone(prev.axes) : newAxes()
		});
		render();
	}

	function handleDelete(id) {
		graphs = graphs.filter((g) => g.graphID !== id);
		views.delete(id);
		render();
	}

	function labelGroupTitle(groupID) {
		let n = 0;
		for (const g of graphs) if (g.groupID === groupID) viewFor(g).setTitle(String.fromCharCode(65 + n++));
	}

	/* Size the graphs so a whole group fits across the page */
	function fitGraphs() {
		const perRow = Math.max(3, ...groupIDs.map((id) => graphs.filter((g) => g.groupID == id).length));
		const sample = container.querySelector('.gm-graphs');
		const avail = ((sample ? sample.clientWidth : container.clientWidth - 160) || 600) - (HT.ctrl ? 64 : 0); // room for the + button
		// each card adds the y-label column, canvas padding, card padding and the gap
		const overhead = 28 + PAD.l + PAD.r + 24 + 16;
		const size = Math.floor(Math.min(280, Math.max(140, avail / perRow - overhead)));
		const snapped = size - (size % COLS); // whole-pixel cells keep the grid crisp
		if (snapped !== graphSize) {
			graphSize = snapped;
			views.forEach((v) => v.resize());
		}
	}

	function render() {
		container.replaceChildren();
		for (const group of groupIDs) {
			if (!groupLabels.has(group)) groupLabels.set(group, `Group ${groupIDs.indexOf(group) + 1}`);
			const label = editLabel({ text: groupLabels.get(group), size: 'lg', vertical: true, onchange: (t) => groupLabels.set(group, t) });
			const ctrls = el(
				'div',
				{ class: 'gm-group-ctrls ctrl-only' },
				button({
					cls: 'btn-blue',
					icon: 'trash',
					tip: 'Delete Graph Group',
					extra: 'btn-xs',
					onclick: () => {
						groupIDs = groupIDs.filter((g) => g !== group);
						render();
					}
				}),
				button({ cls: 'btn-blue', text: 'Autotitle', tip: 'Give graphs alphabetical titles', extra: 'btn-xs', onclick: () => labelGroupTitle(group) })
			);
			const graphsBox = el('div', { class: 'gm-graphs' });
			for (const g of graphs) if (g.groupID == group) graphsBox.appendChild(viewFor(g).root);
			graphsBox.appendChild(
				el(
					'button',
					{ type: 'button', class: 'gm-add-graph ctrl-only', 'data-tip': 'Add a graph to this group', onclick: () => addNewGraph(group) },
					HT.icon('plusCircle')
				)
			);
			container.appendChild(el('section', { class: 'gm-group' }, el('div', { class: 'gm-group-side' }, label.el, ctrls), graphsBox));
		}
		fitGraphs();
	}

	HT.onResize(fitGraphs);
	document.addEventListener('ht-ctrl', () => requestAnimationFrame(fitGraphs));

	/* ---------------- save / load ---------------- */

	/*
	 * Saved form:
	 *   data.groups = [{ id, label, graphs: [{ id, title, quantity, axes, segments }] }]
	 *   axes        = { x: { quantity: 'Time', min, max }, y: { min, max } }   each graph's grid, in graph units
	 *   segment     = { from: [t, v], to: [t, v], shape: 'line' | 'curve-up' | 'curve-down' }
	 * Endpoints are whole grid points. The curve's control point is rebuilt from the shape on load.
	 */
	const sign = (v) => (v > 0 ? 1 : v < 0 ? -1 : 0);

	function toSegment(p) {
		const dy = p.b.y - p.a.y;
		const bend = p.bend ?? 0;
		const shape = bend === 0 || dy === 0 ? 'line' : bend * sign(dy) > 0 ? 'curve-up' : 'curve-down';
		return { from: [p.a.x, p.a.y], to: [p.b.x, p.b.y], shape };
	}

	function fromSegment(seg, axes) {
		const pt = (v) => {
			const x = Math.round(Number(v && v[0]));
			const y = Math.round(Number(v && v[1]));
			return { x: Math.min(axes.x.max, Math.max(axes.x.min, x || 0)), y: Math.min(axes.y.max, Math.max(axes.y.min, y || 0)) };
		};
		const a = pt(seg.from);
		const b = pt(seg.to);
		const want = seg.shape === 'curve-up' ? 1 : seg.shape === 'curve-down' ? -1 : 0;
		const bend = want * sign(b.y - a.y);
		return QualGraph.prototype.pathFor(a, b, bend);
	}

	function resetIds() {
		graphIDIncrement = graphs.reduce((m, g) => Math.max(m, g.graphID), -1);
		groupIDIncrement = Math.max(0, ...groupIDs);
	}

	HT.registerDoc({
		tool: 'graph',
		defaultTitle: () => 'Motion graphs',
		serialize: () => ({
			data: {
				groups: groupIDs.map((gid) => ({
					id: 'grp' + gid,
					label: groupLabels.get(gid) ?? `Group ${groupIDs.indexOf(gid) + 1}`,
					graphs: graphs
						.filter((g) => g.groupID === gid)
						.map((g) => ({
							id: 'g' + g.graphID,
							title: g.title,
							quantity: g.labels.y,
							axes: { x: { quantity: 'Time', ...g.axes.x }, y: { ...g.axes.y } },
							segments: g.pathList.map(toSegment)
						}))
				}))
			},
			view: {}
		}),
		load(file) {
			const groups = Array.isArray(file.data.groups) ? file.data.groups : [];
			graphs = [];
			views.clear();
			groupLabels.clear();
			groupIDs = [];
			let nextGraph = 0;
			groups.forEach((grp, i) => {
				const gid = i;
				groupIDs.push(gid);
				groupLabels.set(gid, grp.label == null ? `Group ${i + 1}` : String(grp.label));
				for (const g of Array.isArray(grp.graphs) ? grp.graphs : []) {
					const a = g.axes || file.data.axes || {}; // older saves kept one set of axes for the page
					const axes = {
						x: HT.cleanAxisRange(a.x, DEFAULT_AXES.x, AXIS_LIMITS.x),
						y: HT.cleanAxisRange(a.y, DEFAULT_AXES.y, AXIS_LIMITS.y)
					};
					graphs.push({
						title: g.title == null ? '' : String(g.title),
						graphID: nextGraph++,
						groupID: gid,
						axes,
						pathList: (Array.isArray(g.segments) ? g.segments : []).map((seg) => fromSegment(seg, axes)),
						labels: { x: 'Time', y: Y_LABELS[g.quantity] ? g.quantity : 'Position' }
					});
				}
			});
			if (!groupIDs.length) groupIDs = [0];
			resetIds();
			render();
		},
		reset() {
			graphs = [];
			views.clear();
			groupLabels.clear();
			groupIDs = [0];
			graphIDIncrement = 0;
			groupIDIncrement = 0;
			addNewGraph(0);
		}
	});

	graphs = [
		{ title: '', graphID: 0, groupID: 0, pathList: [], labels: { x: 'Time', y: 'Position' }, axes: newAxes() },
		{ title: '', graphID: 1, groupID: 0, pathList: [], labels: { x: 'Time', y: 'Velocity' }, axes: newAxes() },
		{ title: '', graphID: 2, groupID: 0, pathList: [], labels: { x: 'Time', y: 'Acceleration' }, axes: newAxes() }
	];
	graphIDIncrement = graphs.length;
	render();
})();
