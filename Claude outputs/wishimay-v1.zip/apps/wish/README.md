# Wish I May

A family wish list. Lives at `/wish/` on the Happy Theta site; its API is part of the Happy Theta
server (`server/wishlist.js`, `server/wish-preview.js`, `server/wish.js`).

## Who does what

- **Owners** share one login. At the top they pick who they're "wishing as" (Mom, Dad, Lily…) and
  add, edit or delete that person's wishes. "People" adds, renames, recolors or removes people.
  "Shopper logins" creates the logins for relatives. Owners never see what's been bought.
- **Shoppers** sign in with the email and passphrase an owner gave them. They search, filter (person,
  priority, price) and sort (newest, oldest, most wanted, price, person, name). **Buy** opens the shop
  page in a new tab and asks "Did you buy it?". Yes takes it off the list for every shopper; it moves
  to that shopper's **My purchases**, where "I didn't buy it" puts it back.
- Priority is three stars: ★★★ Top wish, ★★ Would love, ★ Nice to have.

## Adding a wish

Paste a link and press **Add a wish**: the server reads the page and fills in the name, picture,
description and price (JSON-LD product data, Open Graph tags, Amazon's own page elements). Everything
stays editable. Some shops (Amazon especially) sometimes answer automated requests with a "prove
you're human" page; then the form says so and you fill in the details by hand. A wish doesn't need a
link at all ("Mark as bought" replaces the Buy button).

Pictures are linked, not copied, and loaded with `referrerpolicy="no-referrer"` so shops that block
hotlinking still show them. If a shop moves a picture, paste a new picture link in Edit.

## Try it on your PC

```
cd server
npm install
npm run wish:dev -- owner you@example.com      # asks for a passphrase
npm run dev                                     # then open http://localhost:3000/wish/
```

## Deploy

1. Copy the contents of `apps/wish/` into a `wish/` folder next to `phys/` in the web root.
2. Update the server code on the droplet (`server/`: wishlist.js, wish-preview.js, wish.js, server.js,
   package.json) and `sudo systemctl restart happytheta-api`. The tables are created on start.
3. Add `server/deploy/nginx-wish-api.conf` to the site's nginx `server` block and reload nginx.
4. Make the owner login (see server/README.md, "WishIMay").

Needs HTTPS like the rest of the site (the sign-in cookie is `Secure`).

## Files

```
index.html      page shell (twilight band + app area)
css/wish.css    all styles (light + dark)
js/wish.js      the app: sign in, owner view, shopper view, dialogs
star.svg        favicon
```
